

const Footer = () => (
  <footer>
    <p>&copy; 2024 Amanda Marquez</p>
  </footer>
);

export default Footer;