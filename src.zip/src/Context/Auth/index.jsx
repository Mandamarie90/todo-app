import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext({
  user: null, // Ensure all properties are initialized
  login: () => {},
  logout: () => {},
  hasCapability: () => false,
});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = (username, password) => {
    // Simulate a login logic
    setUser({ username, capabilities: ['read', 'write'] }); // example user object
  };

  const logout = () => {
    setUser(null);
  };

  const hasCapability = (capability) => {
    return user?.capabilities.includes(capability);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, hasCapability }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
